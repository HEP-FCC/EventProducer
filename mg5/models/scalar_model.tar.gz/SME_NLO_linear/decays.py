# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.1.0 for Linux x86 (64-bit) (July 16, 2024)
# Date: Mon 7 Apr 2025 01:09:56


from object_library import all_decays, Decay
import particles as P


Decay_b = Decay(name = 'Decay_b',
                particle = P.b,
                partial_widths = {(P.W__minus__,P.t):'(((3*ee**2*MB**2)/(2.*sw**2) + (3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MB**4)/(2.*MW**2*sw**2) - (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MB)**3)'})

Decay_h1 = Decay(name = 'Decay_h1',
                 particle = P.h1,
                 partial_widths = {(P.b,P.b__tilde__):'((-12*MB**2*yb**2*cmath.cos(theta)**2 + 3*mh1**2*yb**2*cmath.cos(theta)**2)*cmath.sqrt(-4*MB**2*mh1**2 + mh1**4))/(16.*cmath.pi*abs(mh1)**3)',
                                   (P.h2,P.h2):'(cmath.sqrt(mh1**4 - 4*mh1**2*mh2**2)*(a2**2*vH**2*cmath.cos(theta)**6 + 2*a1*a2*vH*cmath.cos(theta)**5*cmath.sin(theta) - 4*a2*b3*vH*cmath.cos(theta)**5*cmath.sin(theta) + a1**2*cmath.cos(theta)**4*cmath.sin(theta)**2 - 4*a1*b3*cmath.cos(theta)**4*cmath.sin(theta)**2 + 4*b3**2*cmath.cos(theta)**4*cmath.sin(theta)**2 - 4*a2**2*vH**2*cmath.cos(theta)**4*cmath.sin(theta)**2 + 12*a2*lamH*vH**2*cmath.cos(theta)**4*cmath.sin(theta)**2 - 5*a1*a2*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 + 8*a2*b3*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 + 12*a1*lamH*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 - 24*b3*lamH*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 - a1**2*cmath.cos(theta)**2*cmath.sin(theta)**4 + 2*a1*b3*cmath.cos(theta)**2*cmath.sin(theta)**4 + 4*a2**2*vH**2*cmath.cos(theta)**2*cmath.sin(theta)**4 - 24*a2*lamH*vH**2*cmath.cos(theta)**2*cmath.sin(theta)**4 + 36*lamH**2*vH**2*cmath.cos(theta)**2*cmath.sin(theta)**4 + 2*a1*a2*vH*cmath.cos(theta)*cmath.sin(theta)**5 - 6*a1*lamH*vH*cmath.cos(theta)*cmath.sin(theta)**5 + (a1**2*cmath.sin(theta)**6)/4.))/(32.*cmath.pi*abs(mh1)**3)',
                                   (P.ta__minus__,P.ta__plus__):'((mh1**2*ytau**2*cmath.cos(theta)**2 - 4*MTA**2*ytau**2*cmath.cos(theta)**2)*cmath.sqrt(mh1**4 - 4*mh1**2*MTA**2))/(16.*cmath.pi*abs(mh1)**3)',
                                   (P.t,P.t__tilde__):'((3*mh1**2*yt**2*cmath.cos(theta)**2 - 12*MT**2*yt**2*cmath.cos(theta)**2)*cmath.sqrt(mh1**4 - 4*mh1**2*MT**2))/(16.*cmath.pi*abs(mh1)**3)',
                                   (P.W__minus__,P.W__plus__):'(((3*ee**4*vH**2*cmath.cos(theta)**2)/(4.*sw**4) + (ee**4*mh1**4*vH**2*cmath.cos(theta)**2)/(16.*MW**4*sw**4) - (ee**4*mh1**2*vH**2*cmath.cos(theta)**2)/(4.*MW**2*sw**4))*cmath.sqrt(mh1**4 - 4*mh1**2*MW**2))/(16.*cmath.pi*abs(mh1)**3)',
                                   (P.Z,P.Z):'(((9*ee**4*vH**2*cmath.cos(theta)**2)/2. + (3*ee**4*mh1**4*vH**2*cmath.cos(theta)**2)/(8.*MZ**4) - (3*ee**4*mh1**2*vH**2*cmath.cos(theta)**2)/(2.*MZ**2) + (3*cw**4*ee**4*vH**2*cmath.cos(theta)**2)/(4.*sw**4) + (cw**4*ee**4*mh1**4*vH**2*cmath.cos(theta)**2)/(16.*MZ**4*sw**4) - (cw**4*ee**4*mh1**2*vH**2*cmath.cos(theta)**2)/(4.*MZ**2*sw**4) + (3*cw**2*ee**4*vH**2*cmath.cos(theta)**2)/sw**2 + (cw**2*ee**4*mh1**4*vH**2*cmath.cos(theta)**2)/(4.*MZ**4*sw**2) - (cw**2*ee**4*mh1**2*vH**2*cmath.cos(theta)**2)/(MZ**2*sw**2) + (3*ee**4*sw**2*vH**2*cmath.cos(theta)**2)/cw**2 + (ee**4*mh1**4*sw**2*vH**2*cmath.cos(theta)**2)/(4.*cw**2*MZ**4) - (ee**4*mh1**2*sw**2*vH**2*cmath.cos(theta)**2)/(cw**2*MZ**2) + (3*ee**4*sw**4*vH**2*cmath.cos(theta)**2)/(4.*cw**4) + (ee**4*mh1**4*sw**4*vH**2*cmath.cos(theta)**2)/(16.*cw**4*MZ**4) - (ee**4*mh1**2*sw**4*vH**2*cmath.cos(theta)**2)/(4.*cw**4*MZ**2))*cmath.sqrt(mh1**4 - 4*mh1**2*MZ**2))/(32.*cmath.pi*abs(mh1)**3)'})

Decay_h2 = Decay(name = 'Decay_h2',
                 particle = P.h2,
                 partial_widths = {(P.b,P.b__tilde__):'(cmath.sqrt(-4*MB**2*mh2**2 + mh2**4)*(-12*MB**2*yb**2*cmath.sin(theta)**2 + 3*mh2**2*yb**2*cmath.sin(theta)**2))/(16.*cmath.pi*abs(mh2)**3)',
                                   (P.h1,P.h1):'(cmath.sqrt(-4*mh1**2*mh2**2 + mh2**4)*((a1**2*cmath.cos(theta)**6)/4. - 2*a1*a2*vH*cmath.cos(theta)**5*cmath.sin(theta) + 6*a1*lamH*vH*cmath.cos(theta)**5*cmath.sin(theta) - a1**2*cmath.cos(theta)**4*cmath.sin(theta)**2 + 2*a1*b3*cmath.cos(theta)**4*cmath.sin(theta)**2 + 4*a2**2*vH**2*cmath.cos(theta)**4*cmath.sin(theta)**2 - 24*a2*lamH*vH**2*cmath.cos(theta)**4*cmath.sin(theta)**2 + 36*lamH**2*vH**2*cmath.cos(theta)**4*cmath.sin(theta)**2 + 5*a1*a2*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 - 8*a2*b3*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 - 12*a1*lamH*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 + 24*b3*lamH*vH*cmath.cos(theta)**3*cmath.sin(theta)**3 + a1**2*cmath.cos(theta)**2*cmath.sin(theta)**4 - 4*a1*b3*cmath.cos(theta)**2*cmath.sin(theta)**4 + 4*b3**2*cmath.cos(theta)**2*cmath.sin(theta)**4 - 4*a2**2*vH**2*cmath.cos(theta)**2*cmath.sin(theta)**4 + 12*a2*lamH*vH**2*cmath.cos(theta)**2*cmath.sin(theta)**4 - 2*a1*a2*vH*cmath.cos(theta)*cmath.sin(theta)**5 + 4*a2*b3*vH*cmath.cos(theta)*cmath.sin(theta)**5 + a2**2*vH**2*cmath.sin(theta)**6))/(32.*cmath.pi*abs(mh2)**3)',
                                   (P.ta__minus__,P.ta__plus__):'(cmath.sqrt(mh2**4 - 4*mh2**2*MTA**2)*(mh2**2*ytau**2*cmath.sin(theta)**2 - 4*MTA**2*ytau**2*cmath.sin(theta)**2))/(16.*cmath.pi*abs(mh2)**3)',
                                   (P.t,P.t__tilde__):'(cmath.sqrt(mh2**4 - 4*mh2**2*MT**2)*(3*mh2**2*yt**2*cmath.sin(theta)**2 - 12*MT**2*yt**2*cmath.sin(theta)**2))/(16.*cmath.pi*abs(mh2)**3)',
                                   (P.W__minus__,P.W__plus__):'(cmath.sqrt(mh2**4 - 4*mh2**2*MW**2)*((3*ee**4*vH**2*cmath.sin(theta)**2)/(4.*sw**4) + (ee**4*mh2**4*vH**2*cmath.sin(theta)**2)/(16.*MW**4*sw**4) - (ee**4*mh2**2*vH**2*cmath.sin(theta)**2)/(4.*MW**2*sw**4)))/(16.*cmath.pi*abs(mh2)**3)',
                                   (P.Z,P.Z):'(cmath.sqrt(mh2**4 - 4*mh2**2*MZ**2)*((9*ee**4*vH**2*cmath.sin(theta)**2)/2. + (3*ee**4*mh2**4*vH**2*cmath.sin(theta)**2)/(8.*MZ**4) - (3*ee**4*mh2**2*vH**2*cmath.sin(theta)**2)/(2.*MZ**2) + (3*cw**4*ee**4*vH**2*cmath.sin(theta)**2)/(4.*sw**4) + (cw**4*ee**4*mh2**4*vH**2*cmath.sin(theta)**2)/(16.*MZ**4*sw**4) - (cw**4*ee**4*mh2**2*vH**2*cmath.sin(theta)**2)/(4.*MZ**2*sw**4) + (3*cw**2*ee**4*vH**2*cmath.sin(theta)**2)/sw**2 + (cw**2*ee**4*mh2**4*vH**2*cmath.sin(theta)**2)/(4.*MZ**4*sw**2) - (cw**2*ee**4*mh2**2*vH**2*cmath.sin(theta)**2)/(MZ**2*sw**2) + (3*ee**4*sw**2*vH**2*cmath.sin(theta)**2)/cw**2 + (ee**4*mh2**4*sw**2*vH**2*cmath.sin(theta)**2)/(4.*cw**2*MZ**4) - (ee**4*mh2**2*sw**2*vH**2*cmath.sin(theta)**2)/(cw**2*MZ**2) + (3*ee**4*sw**4*vH**2*cmath.sin(theta)**2)/(4.*cw**4) + (ee**4*mh2**4*sw**4*vH**2*cmath.sin(theta)**2)/(16.*cw**4*MZ**4) - (ee**4*mh2**2*sw**4*vH**2*cmath.sin(theta)**2)/(4.*cw**4*MZ**2)))/(32.*cmath.pi*abs(mh2)**3)'})

Decay_t = Decay(name = 'Decay_t',
                particle = P.t,
                partial_widths = {(P.W__plus__,P.b):'(((3*ee**2*MB**2)/(2.*sw**2) + (3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MB**4)/(2.*MW**2*sw**2) - (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(96.*cmath.pi*abs(MT)**3)'})

Decay_ta__minus__ = Decay(name = 'Decay_ta__minus__',
                          particle = P.ta__minus__,
                          partial_widths = {(P.W__minus__,P.vt):'((MTA**2 - MW**2)*((ee**2*MTA**2)/(2.*sw**2) + (ee**2*MTA**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(MTA)**3)'})

Decay_W__plus__ = Decay(name = 'Decay_W__plus__',
                        particle = P.W__plus__,
                        partial_widths = {(P.c,P.s__tilde__):'(ee**2*MW**4)/(16.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.t,P.b__tilde__):'(((-3*ee**2*MB**2)/(2.*sw**2) - (3*ee**2*MT**2)/(2.*sw**2) - (3*ee**2*MB**4)/(2.*MW**2*sw**2) + (3*ee**2*MB**2*MT**2)/(MW**2*sw**2) - (3*ee**2*MT**4)/(2.*MW**2*sw**2) + (3*ee**2*MW**2)/sw**2)*cmath.sqrt(MB**4 - 2*MB**2*MT**2 + MT**4 - 2*MB**2*MW**2 - 2*MT**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.u,P.d__tilde__):'(ee**2*MW**4)/(16.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.ve,P.e__plus__):'(ee**2*MW**4)/(48.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.vm,P.mu__plus__):'(ee**2*MW**4)/(48.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.vt,P.ta__plus__):'((-MTA**2 + MW**2)*(-0.5*(ee**2*MTA**2)/sw**2 - (ee**2*MTA**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)'})

Decay_Z = Decay(name = 'Decay_Z',
                particle = P.Z,
                partial_widths = {(P.b,P.b__tilde__):'((-7*ee**2*MB**2 + ee**2*MZ**2 - (3*cw**2*ee**2*MB**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) - (17*ee**2*MB**2*sw**2)/(6.*cw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MB**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.c,P.c__tilde__):'(MZ**2*(-(ee**2*MZ**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.d,P.d__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.e__minus__,P.e__plus__):'(MZ**2*(-(ee**2*MZ**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.mu__minus__,P.mu__plus__):'(MZ**2*(-(ee**2*MZ**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.s,P.s__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((-5*ee**2*MTA**2 - ee**2*MZ**2 - (cw**2*ee**2*MTA**2)/(2.*sw**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MTA**2*sw**2)/(2.*cw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MTA**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.t,P.t__tilde__):'((-11*ee**2*MT**2 - ee**2*MZ**2 - (3*cw**2*ee**2*MT**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MT**2*sw**2)/(6.*cw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MT**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.u,P.u__tilde__):'(MZ**2*(-(ee**2*MZ**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ve,P.ve__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vm,P.vm__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vt,P.vt__tilde__):'(MZ**2*(ee**2*MZ**2 + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.W__minus__,P.W__plus__):'(((-12*cw**2*ee**2*MW**2)/sw**2 - (17*cw**2*ee**2*MZ**2)/sw**2 + (4*cw**2*ee**2*MZ**4)/(MW**2*sw**2) + (cw**2*ee**2*MZ**6)/(4.*MW**4*sw**2))*cmath.sqrt(-4*MW**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)'})

