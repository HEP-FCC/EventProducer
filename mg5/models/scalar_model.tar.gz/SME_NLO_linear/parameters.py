# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.1.0 for Linux x86 (64-bit) (July 16, 2024)
# Date: Mon 7 Apr 2025 01:09:56



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# This is a default parameter object representing the renormalization scale (MU_R).
MU_R = Parameter(name = 'MU_R',
                 nature = 'external',
                 type = 'real',
                 value = 91.188,
                 texname = '\\text{\\mu_r}',
                 lhablock = 'LOOP',
                 lhacode = [1])

# User-defined parameters.
theta = Parameter(name = 'theta',
                  nature = 'external',
                  type = 'real',
                  value = 0.1,
                  texname = '\\theta',
                  lhablock = 'MSExtension',
                  lhacode = [ 1 ])

a2 = Parameter(name = 'a2',
               nature = 'external',
               type = 'real',
               value = 1.,
               texname = 'a_2',
               lhablock = 'MSExtension',
               lhacode = [ 2 ])

b3 = Parameter(name = 'b3',
               nature = 'external',
               type = 'real',
               value = 100.,
               texname = 'b_3',
               lhablock = 'MSExtension',
               lhacode = [ 3 ])

b4 = Parameter(name = 'b4',
               nature = 'external',
               type = 'real',
               value = 0.25,
               texname = 'b_4',
               lhablock = 'MSExtension',
               lhacode = [ 4 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1184,
               texname = '\\alpha _s',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

ymb = Parameter(name = 'ymb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{ymb}',
                lhablock = 'YUKAWA',
                lhacode = [ 5 ])

ymt = Parameter(name = 'ymt',
                nature = 'external',
                type = 'real',
                value = 172,
                texname = '\\text{ymt}',
                lhablock = 'YUKAWA',
                lhacode = [ 6 ])

ymtau = Parameter(name = 'ymtau',
                  nature = 'external',
                  type = 'real',
                  value = 1.777,
                  texname = '\\text{ymtau}',
                  lhablock = 'YUKAWA',
                  lhacode = [ 15 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

MTA = Parameter(name = 'MTA',
                nature = 'external',
                type = 'real',
                value = 1.777,
                texname = '\\text{MTA}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 172,
               texname = '\\text{MT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

MB = Parameter(name = 'MB',
               nature = 'external',
               type = 'real',
               value = 4.7,
               texname = '\\text{MB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

mh1 = Parameter(name = 'mh1',
                nature = 'external',
                type = 'real',
                value = 125.02,
                texname = '\\text{mh1}',
                lhablock = 'MASS',
                lhacode = [ 9000005 ])

mh2 = Parameter(name = 'mh2',
                nature = 'external',
                type = 'real',
                value = 1000.,
                texname = '\\text{mh2}',
                lhablock = 'MASS',
                lhacode = [ 9000006 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

wh1 = Parameter(name = 'wh1',
                nature = 'external',
                type = 'real',
                value = 0.004,
                texname = '\\text{wh1}',
                lhablock = 'DECAY',
                lhacode = [ 9000005 ])

wh2 = Parameter(name = 'wh2',
                nature = 'external',
                type = 'real',
                value = 2,
                texname = '\\text{wh2}',
                lhablock = 'DECAY',
                lhacode = [ 9000006 ])

MM1x1 = Parameter(name = 'MM1x1',
                  nature = 'internal',
                  type = 'real',
                  value = '(mh1**2 + mh2**2 + (mh1**2 - mh2**2)*cmath.cos(2*theta))/2.',
                  texname = '\\text{MM1x1}')

MM1x2 = Parameter(name = 'MM1x2',
                  nature = 'internal',
                  type = 'real',
                  value = '(-mh1**2 + mh2**2)*cmath.cos(theta)*cmath.sin(theta)',
                  texname = '\\text{MM1x2}')

MM2x1 = Parameter(name = 'MM2x1',
                  nature = 'internal',
                  type = 'real',
                  value = '(-mh1**2 + mh2**2)*cmath.cos(theta)*cmath.sin(theta)',
                  texname = '\\text{MM2x1}')

MM2x2 = Parameter(name = 'MM2x2',
                  nature = 'internal',
                  type = 'real',
                  value = '(mh1**2 + mh2**2 - (mh1**2 - mh2**2)*cmath.cos(2*theta))/2.',
                  texname = '\\text{MM2x2}')

UU1x1 = Parameter(name = 'UU1x1',
                  nature = 'internal',
                  type = 'real',
                  value = 'cmath.cos(theta)',
                  texname = '\\text{UU1x1}')

UU1x2 = Parameter(name = 'UU1x2',
                  nature = 'internal',
                  type = 'real',
                  value = '-cmath.sin(theta)',
                  texname = '\\text{UU1x2}')

UU2x1 = Parameter(name = 'UU2x1',
                  nature = 'internal',
                  type = 'real',
                  value = 'cmath.sin(theta)',
                  texname = '\\text{UU2x1}')

UU2x2 = Parameter(name = 'UU2x2',
                  nature = 'internal',
                  type = 'real',
                  value = 'cmath.cos(theta)',
                  texname = '\\text{UU2x2}')

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\alpha _{\\text{EW}}')

G = Parameter(name = 'G',
              nature = 'internal',
              type = 'real',
              value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
              texname = 'G')

MW = Parameter(name = 'MW',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (aEW*cmath.pi*MZ**2)/(Gf*cmath.sqrt(2))))',
               texname = 'M_W')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

sw2 = Parameter(name = 'sw2',
                nature = 'internal',
                type = 'real',
                value = '1 - MW**2/MZ**2',
                texname = '\\text{sw2}')

cw = Parameter(name = 'cw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(1 - sw2)',
               texname = 'c_w')

sw = Parameter(name = 'sw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(sw2)',
               texname = 's_w')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = 'ee/cw',
               texname = 'g_1')

gw = Parameter(name = 'gw',
               nature = 'internal',
               type = 'real',
               value = 'ee/sw',
               texname = 'g_w')

vH = Parameter(name = 'vH',
               nature = 'internal',
               type = 'real',
               value = '(2*MW*sw)/ee',
               texname = 'v_H')

muS = Parameter(name = 'muS',
                nature = 'internal',
                type = 'real',
                value = '(-mh1**2 - mh2**2 + a2*vH**2 - (-mh1**2 + mh2**2)*cmath.cos(2*theta))/2.',
                texname = '\\mu _S')

a1 = Parameter(name = 'a1',
               nature = 'internal',
               type = 'real',
               value = '((-mh1**2 + mh2**2)*cmath.sin(2*theta))/vH',
               texname = 'a_1')

lamH = Parameter(name = 'lamH',
                 nature = 'internal',
                 type = 'real',
                 value = 'MM1x1/(2.*vH**2)',
                 texname = '\\lambda _H')

yb = Parameter(name = 'yb',
               nature = 'internal',
               type = 'real',
               value = '(ymb*cmath.sqrt(2))/vH',
               texname = '\\text{yb}')

yt = Parameter(name = 'yt',
               nature = 'internal',
               type = 'real',
               value = '(ymt*cmath.sqrt(2))/vH',
               texname = '\\text{yt}')

ytau = Parameter(name = 'ytau',
                 nature = 'internal',
                 type = 'real',
                 value = '(ymtau*cmath.sqrt(2))/vH',
                 texname = '\\text{ytau}')

b1 = Parameter(name = 'b1',
               nature = 'internal',
               type = 'real',
               value = '-0.25*(a1*vH**2)',
               texname = 'b_1')

muH = Parameter(name = 'muH',
                nature = 'internal',
                type = 'real',
                value = 'lamH*vH',
                texname = '\\mu _H')

I1a33 = Parameter(name = 'I1a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yb',
                  texname = '\\text{I1a33}')

I2a33 = Parameter(name = 'I2a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yt',
                  texname = '\\text{I2a33}')

I3a33 = Parameter(name = 'I3a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yt',
                  texname = '\\text{I3a33}')

I4a33 = Parameter(name = 'I4a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yb',
                  texname = '\\text{I4a33}')

