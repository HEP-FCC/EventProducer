# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 14.1.0 for Linux x86 (64-bit) (July 16, 2024)
# Date: Mon 7 Apr 2025 01:09:56


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



GC_1 = Coupling(name = 'GC_1',
                value = '-0.3333333333333333*(ee*complex(0,1))',
                order = {'QED':1})

GC_10 = Coupling(name = 'GC_10',
                 value = 'complex(0,1)*G',
                 order = {'QCD':1})

GC_11 = Coupling(name = 'GC_11',
                 value = 'G',
                 order = {'QCD':1})

GC_12 = Coupling(name = 'GC_12',
                 value = '-(complex(0,1)*G**2)',
                 order = {'QCD':2})

GC_13 = Coupling(name = 'GC_13',
                 value = 'complex(0,1)*G**2',
                 order = {'QCD':2})

GC_14 = Coupling(name = 'GC_14',
                 value = 'I1a33',
                 order = {'QED':1})

GC_15 = Coupling(name = 'GC_15',
                 value = '-I2a33',
                 order = {'QED':1})

GC_16 = Coupling(name = 'GC_16',
                 value = 'I3a33',
                 order = {'QED':1})

GC_17 = Coupling(name = 'GC_17',
                 value = '-I4a33',
                 order = {'QED':1})

GC_174 = Coupling(name = 'GC_174',
                  value = '-0.5*(ee**2*cmath.sin(theta))/cw',
                  order = {'QED':2})

GC_175 = Coupling(name = 'GC_175',
                  value = '(ee**2*cmath.sin(theta))/(2.*cw)',
                  order = {'QED':2})

GC_176 = Coupling(name = 'GC_176',
                  value = '-0.5*(ee*cmath.sin(theta))/sw',
                  order = {'QED':1})

GC_177 = Coupling(name = 'GC_177',
                  value = '(ee*cmath.sin(theta))/(2.*sw)',
                  order = {'QED':1})

GC_178 = Coupling(name = 'GC_178',
                  value = '-0.5*(ee**2*cmath.sin(theta))/sw',
                  order = {'QED':2})

GC_179 = Coupling(name = 'GC_179',
                  value = '(ee**2*cmath.sin(theta))/(2.*sw)',
                  order = {'QED':2})

GC_18 = Coupling(name = 'GC_18',
                 value = '-2*complex(0,1)*lamH',
                 order = {'QED':2})

GC_180 = Coupling(name = 'GC_180',
                  value = '-0.25*(ee**2*complex(0,1)*vH*cmath.sin(theta))/sw**2',
                  order = {'QED':1})

GC_181 = Coupling(name = 'GC_181',
                  value = '(ee**2*complex(0,1)*vH*cmath.sin(theta))/(2.*sw**2)',
                  order = {'QED':1})

GC_182 = Coupling(name = 'GC_182',
                  value = '-((complex(0,1)*yb*cmath.sin(theta))/cmath.sqrt(2))',
                  order = {'QED':1})

GC_183 = Coupling(name = 'GC_183',
                  value = '-((complex(0,1)*yt*cmath.sin(theta))/cmath.sqrt(2))',
                  order = {'QED':1})

GC_184 = Coupling(name = 'GC_184',
                  value = '-((complex(0,1)*ytau*cmath.sin(theta))/cmath.sqrt(2))',
                  order = {'QED':1})

GC_185 = Coupling(name = 'GC_185',
                  value = '(ee**2*complex(0,1)*cmath.cos(theta)*cmath.sin(theta))/(2.*sw**2)',
                  order = {'QED':2})

GC_186 = Coupling(name = 'GC_186',
                  value = '(ee**2*complex(0,1)*cmath.sin(theta)**2)/(2.*sw**2)',
                  order = {'QED':2})

GC_187 = Coupling(name = 'GC_187',
                  value = '-2*complex(0,1)*lamH*vH*cmath.cos(theta) + (a1*complex(0,1)*cmath.sin(theta))/2.',
                  order = {'QED':1})

GC_188 = Coupling(name = 'GC_188',
                  value = '-0.5*(cw*ee*cmath.sin(theta))/sw - (ee*sw*cmath.sin(theta))/(2.*cw)',
                  order = {'QED':1})

GC_189 = Coupling(name = 'GC_189',
                  value = '-0.5*(a1*complex(0,1)*cmath.cos(theta)) - 2*complex(0,1)*lamH*vH*cmath.sin(theta)',
                  order = {'QED':1})

GC_19 = Coupling(name = 'GC_19',
                 value = '-4*complex(0,1)*lamH',
                 order = {'QED':2})

GC_190 = Coupling(name = 'GC_190',
                  value = '-0.5*(ee**2*complex(0,1)*vH*cmath.sin(theta)) - (cw**2*ee**2*complex(0,1)*vH*cmath.sin(theta))/(4.*sw**2) - (ee**2*complex(0,1)*sw**2*vH*cmath.sin(theta))/(4.*cw**2)',
                  order = {'QED':1})

GC_191 = Coupling(name = 'GC_191',
                  value = 'ee**2*complex(0,1)*vH*cmath.sin(theta) + (cw**2*ee**2*complex(0,1)*vH*cmath.sin(theta))/(2.*sw**2) + (ee**2*complex(0,1)*sw**2*vH*cmath.sin(theta))/(2.*cw**2)',
                  order = {'QED':1})

GC_192 = Coupling(name = 'GC_192',
                  value = 'a2*complex(0,1)*cmath.cos(theta)*cmath.sin(theta) - 2*complex(0,1)*lamH*cmath.cos(theta)*cmath.sin(theta)',
                  order = {'QED':2})

GC_193 = Coupling(name = 'GC_193',
                  value = 'ee**2*complex(0,1)*cmath.cos(theta)*cmath.sin(theta) + (cw**2*ee**2*complex(0,1)*cmath.cos(theta)*cmath.sin(theta))/(2.*sw**2) + (ee**2*complex(0,1)*sw**2*cmath.cos(theta)*cmath.sin(theta))/(2.*cw**2)',
                  order = {'QED':2})

GC_197 = Coupling(name = 'GC_197',
                  value = '-2*complex(0,1)*lamH*cmath.cos(theta)**2 - a2*complex(0,1)*cmath.sin(theta)**2',
                  order = {'QED':2})

GC_198 = Coupling(name = 'GC_198',
                  value = '-(a2*complex(0,1)*cmath.cos(theta)**2) - 2*complex(0,1)*lamH*cmath.sin(theta)**2',
                  order = {'QED':2})

GC_199 = Coupling(name = 'GC_199',
                  value = 'ee**2*complex(0,1)*cmath.sin(theta)**2 + (cw**2*ee**2*complex(0,1)*cmath.sin(theta)**2)/(2.*sw**2) + (ee**2*complex(0,1)*sw**2*cmath.sin(theta)**2)/(2.*cw**2)',
                  order = {'QED':2})

GC_2 = Coupling(name = 'GC_2',
                value = '(2*ee*complex(0,1))/3.',
                order = {'QED':1})

GC_20 = Coupling(name = 'GC_20',
                 value = '-6*complex(0,1)*lamH',
                 order = {'QED':2})

GC_201 = Coupling(name = 'GC_201',
                  value = '-(a2*complex(0,1)*vH*cmath.cos(theta)**3) - a1*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta) + 2*b3*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta) + 2*a2*complex(0,1)*vH*cmath.cos(theta)*cmath.sin(theta)**2 - 6*complex(0,1)*lamH*vH*cmath.cos(theta)*cmath.sin(theta)**2 + (a1*complex(0,1)*cmath.sin(theta)**3)/2.',
                  order = {'QED':1})

GC_202 = Coupling(name = 'GC_202',
                  value = '-6*complex(0,1)*lamH*vH*cmath.cos(theta)**3 + (3*a1*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta))/2. - 3*a2*complex(0,1)*vH*cmath.cos(theta)*cmath.sin(theta)**2 + 2*b3*complex(0,1)*cmath.sin(theta)**3',
                  order = {'QED':1})

GC_203 = Coupling(name = 'GC_203',
                  value = '-0.5*(a1*complex(0,1)*cmath.cos(theta)**3) + 2*a2*complex(0,1)*vH*cmath.cos(theta)**2*cmath.sin(theta) - 6*complex(0,1)*lamH*vH*cmath.cos(theta)**2*cmath.sin(theta) + a1*complex(0,1)*cmath.cos(theta)*cmath.sin(theta)**2 - 2*b3*complex(0,1)*cmath.cos(theta)*cmath.sin(theta)**2 - a2*complex(0,1)*vH*cmath.sin(theta)**3',
                  order = {'QED':1})

GC_204 = Coupling(name = 'GC_204',
                  value = '-2*b3*complex(0,1)*cmath.cos(theta)**3 - 3*a2*complex(0,1)*vH*cmath.cos(theta)**2*cmath.sin(theta) - (3*a1*complex(0,1)*cmath.cos(theta)*cmath.sin(theta)**2)/2. - 6*complex(0,1)*lamH*vH*cmath.sin(theta)**3',
                  order = {'QED':1})

GC_205 = Coupling(name = 'GC_205',
                  value = '3*a2*complex(0,1)*cmath.cos(theta)**3*cmath.sin(theta) - 6*complex(0,1)*lamH*cmath.cos(theta)**3*cmath.sin(theta) - 3*a2*complex(0,1)*cmath.cos(theta)*cmath.sin(theta)**3 + 6*b4*complex(0,1)*cmath.cos(theta)*cmath.sin(theta)**3',
                  order = {'QED':2})

GC_206 = Coupling(name = 'GC_206',
                  value = '-3*a2*complex(0,1)*cmath.cos(theta)**3*cmath.sin(theta) + 6*b4*complex(0,1)*cmath.cos(theta)**3*cmath.sin(theta) + 3*a2*complex(0,1)*cmath.cos(theta)*cmath.sin(theta)**3 - 6*complex(0,1)*lamH*cmath.cos(theta)*cmath.sin(theta)**3',
                  order = {'QED':2})

GC_207 = Coupling(name = 'GC_207',
                  value = '-(a2*complex(0,1)*cmath.cos(theta)**4) + 4*a2*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta)**2 - 6*b4*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta)**2 - 6*complex(0,1)*lamH*cmath.cos(theta)**2*cmath.sin(theta)**2 - a2*complex(0,1)*cmath.sin(theta)**4',
                  order = {'QED':2})

GC_208 = Coupling(name = 'GC_208',
                  value = '-6*complex(0,1)*lamH*cmath.cos(theta)**4 - 6*a2*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta)**2 - 6*b4*complex(0,1)*cmath.sin(theta)**4',
                  order = {'QED':2})

GC_209 = Coupling(name = 'GC_209',
                  value = '-6*b4*complex(0,1)*cmath.cos(theta)**4 - 6*a2*complex(0,1)*cmath.cos(theta)**2*cmath.sin(theta)**2 - 6*complex(0,1)*lamH*cmath.sin(theta)**4',
                  order = {'QED':2})

GC_21 = Coupling(name = 'GC_21',
                 value = '(ee**2*complex(0,1))/(2.*sw**2)',
                 order = {'QED':2})

GC_22 = Coupling(name = 'GC_22',
                 value = '-((ee**2*complex(0,1))/sw**2)',
                 order = {'QED':2})

GC_23 = Coupling(name = 'GC_23',
                 value = '(cw**2*ee**2*complex(0,1))/sw**2',
                 order = {'QED':2})

GC_24 = Coupling(name = 'GC_24',
                 value = '-0.5*(ee*complex(0,1))/sw',
                 order = {'QED':1})

GC_25 = Coupling(name = 'GC_25',
                 value = '(ee*complex(0,1))/(2.*sw)',
                 order = {'QED':1})

GC_26 = Coupling(name = 'GC_26',
                 value = '(ee*complex(0,1))/(sw*cmath.sqrt(2))',
                 order = {'QED':1})

GC_27 = Coupling(name = 'GC_27',
                 value = '-((cw*ee*complex(0,1))/sw)',
                 order = {'QED':1})

GC_28 = Coupling(name = 'GC_28',
                 value = '(cw*ee*complex(0,1))/sw',
                 order = {'QED':1})

GC_29 = Coupling(name = 'GC_29',
                 value = '-0.5*(ee**2*complex(0,1))/sw',
                 order = {'QED':2})

GC_3 = Coupling(name = 'GC_3',
                value = '-(ee*complex(0,1))',
                order = {'QED':1})

GC_30 = Coupling(name = 'GC_30',
                 value = '(-2*cw*ee**2*complex(0,1))/sw',
                 order = {'QED':2})

GC_31 = Coupling(name = 'GC_31',
                 value = '(ee*complex(0,1)*sw)/(3.*cw)',
                 order = {'QED':1})

GC_32 = Coupling(name = 'GC_32',
                 value = '(-2*ee*complex(0,1)*sw)/(3.*cw)',
                 order = {'QED':1})

GC_33 = Coupling(name = 'GC_33',
                 value = '(ee*complex(0,1)*sw)/cw',
                 order = {'QED':1})

GC_34 = Coupling(name = 'GC_34',
                 value = '-0.5*(cw*ee*complex(0,1))/sw - (ee*complex(0,1)*sw)/(6.*cw)',
                 order = {'QED':1})

GC_35 = Coupling(name = 'GC_35',
                 value = '(cw*ee*complex(0,1))/(2.*sw) - (ee*complex(0,1)*sw)/(6.*cw)',
                 order = {'QED':1})

GC_36 = Coupling(name = 'GC_36',
                 value = '-0.5*(cw*ee*complex(0,1))/sw + (ee*complex(0,1)*sw)/(2.*cw)',
                 order = {'QED':1})

GC_37 = Coupling(name = 'GC_37',
                 value = '(cw*ee*complex(0,1))/(2.*sw) + (ee*complex(0,1)*sw)/(2.*cw)',
                 order = {'QED':1})

GC_38 = Coupling(name = 'GC_38',
                 value = '(cw*ee**2*complex(0,1))/sw - (ee**2*complex(0,1)*sw)/cw',
                 order = {'QED':2})

GC_39 = Coupling(name = 'GC_39',
                 value = '-(ee**2*complex(0,1)) + (cw**2*ee**2*complex(0,1))/(2.*sw**2) + (ee**2*complex(0,1)*sw**2)/(2.*cw**2)',
                 order = {'QED':2})

GC_4 = Coupling(name = 'GC_4',
                value = 'ee*complex(0,1)',
                order = {'QED':1})

GC_40 = Coupling(name = 'GC_40',
                 value = 'ee**2*complex(0,1) + (cw**2*ee**2*complex(0,1))/(2.*sw**2) + (ee**2*complex(0,1)*sw**2)/(2.*cw**2)',
                 order = {'QED':2})

GC_41 = Coupling(name = 'GC_41',
                 value = '-0.5*(ee**2*vH)/cw',
                 order = {'QED':1})

GC_42 = Coupling(name = 'GC_42',
                 value = '(ee**2*vH)/(2.*cw)',
                 order = {'QED':1})

GC_43 = Coupling(name = 'GC_43',
                 value = '-0.25*(ee**2*vH)/sw**2',
                 order = {'QED':1})

GC_44 = Coupling(name = 'GC_44',
                 value = '(ee**2*vH)/(4.*sw**2)',
                 order = {'QED':1})

GC_45 = Coupling(name = 'GC_45',
                 value = '-0.5*(ee**2*vH)/sw',
                 order = {'QED':1})

GC_46 = Coupling(name = 'GC_46',
                 value = '(ee**2*vH)/(2.*sw)',
                 order = {'QED':1})

GC_47 = Coupling(name = 'GC_47',
                 value = '-0.25*(ee**2*vH)/cw - (cw*ee**2*vH)/(4.*sw**2)',
                 order = {'QED':1})

GC_48 = Coupling(name = 'GC_48',
                 value = '(ee**2*vH)/(4.*cw) - (cw*ee**2*vH)/(4.*sw**2)',
                 order = {'QED':1})

GC_49 = Coupling(name = 'GC_49',
                 value = '-0.25*(ee**2*vH)/cw + (cw*ee**2*vH)/(4.*sw**2)',
                 order = {'QED':1})

GC_5 = Coupling(name = 'GC_5',
                value = 'ee**2*complex(0,1)',
                order = {'QED':2})

GC_50 = Coupling(name = 'GC_50',
                 value = '(ee**2*vH)/(4.*cw) + (cw*ee**2*vH)/(4.*sw**2)',
                 order = {'QED':1})

GC_51 = Coupling(name = 'GC_51',
                 value = '-(yb/cmath.sqrt(2))',
                 order = {'QED':1})

GC_52 = Coupling(name = 'GC_52',
                 value = 'yb/cmath.sqrt(2)',
                 order = {'QED':1})

GC_53 = Coupling(name = 'GC_53',
                 value = '-(yt/cmath.sqrt(2))',
                 order = {'QED':1})

GC_54 = Coupling(name = 'GC_54',
                 value = 'yt/cmath.sqrt(2)',
                 order = {'QED':1})

GC_55 = Coupling(name = 'GC_55',
                 value = '-ytau',
                 order = {'QED':1})

GC_56 = Coupling(name = 'GC_56',
                 value = 'ytau',
                 order = {'QED':1})

GC_57 = Coupling(name = 'GC_57',
                 value = '-(ytau/cmath.sqrt(2))',
                 order = {'QED':1})

GC_58 = Coupling(name = 'GC_58',
                 value = 'ytau/cmath.sqrt(2)',
                 order = {'QED':1})

GC_59 = Coupling(name = 'GC_59',
                 value = '-0.5*(ee**2*cmath.cos(theta))/cw',
                 order = {'QED':2})

GC_6 = Coupling(name = 'GC_6',
                value = '-2*ee**2*complex(0,1)',
                order = {'QED':2})

GC_60 = Coupling(name = 'GC_60',
                 value = '(ee**2*cmath.cos(theta))/(2.*cw)',
                 order = {'QED':2})

GC_61 = Coupling(name = 'GC_61',
                 value = '-0.5*(ee*cmath.cos(theta))/sw',
                 order = {'QED':1})

GC_62 = Coupling(name = 'GC_62',
                 value = '(ee*cmath.cos(theta))/(2.*sw)',
                 order = {'QED':1})

GC_63 = Coupling(name = 'GC_63',
                 value = '-0.5*(ee**2*cmath.cos(theta))/sw',
                 order = {'QED':2})

GC_64 = Coupling(name = 'GC_64',
                 value = '(ee**2*cmath.cos(theta))/(2.*sw)',
                 order = {'QED':2})

GC_65 = Coupling(name = 'GC_65',
                 value = '-0.25*(ee**2*complex(0,1)*vH*cmath.cos(theta))/sw**2',
                 order = {'QED':1})

GC_66 = Coupling(name = 'GC_66',
                 value = '(ee**2*complex(0,1)*vH*cmath.cos(theta))/(2.*sw**2)',
                 order = {'QED':1})

GC_67 = Coupling(name = 'GC_67',
                 value = '-((complex(0,1)*yb*cmath.cos(theta))/cmath.sqrt(2))',
                 order = {'QED':1})

GC_68 = Coupling(name = 'GC_68',
                 value = '-((complex(0,1)*yt*cmath.cos(theta))/cmath.sqrt(2))',
                 order = {'QED':1})

GC_69 = Coupling(name = 'GC_69',
                 value = '-((complex(0,1)*ytau*cmath.cos(theta))/cmath.sqrt(2))',
                 order = {'QED':1})

GC_7 = Coupling(name = 'GC_7',
                value = '2*ee**2*complex(0,1)',
                order = {'QED':2})

GC_70 = Coupling(name = 'GC_70',
                 value = '(ee**2*complex(0,1)*cmath.cos(theta)**2)/(2.*sw**2)',
                 order = {'QED':2})

GC_71 = Coupling(name = 'GC_71',
                 value = '-0.5*(cw*ee*cmath.cos(theta))/sw - (ee*sw*cmath.cos(theta))/(2.*cw)',
                 order = {'QED':1})

GC_72 = Coupling(name = 'GC_72',
                 value = '-0.5*(ee**2*complex(0,1)*vH*cmath.cos(theta)) - (cw**2*ee**2*complex(0,1)*vH*cmath.cos(theta))/(4.*sw**2) - (ee**2*complex(0,1)*sw**2*vH*cmath.cos(theta))/(4.*cw**2)',
                 order = {'QED':1})

GC_73 = Coupling(name = 'GC_73',
                 value = 'ee**2*complex(0,1)*vH*cmath.cos(theta) + (cw**2*ee**2*complex(0,1)*vH*cmath.cos(theta))/(2.*sw**2) + (ee**2*complex(0,1)*sw**2*vH*cmath.cos(theta))/(2.*cw**2)',
                 order = {'QED':1})

GC_74 = Coupling(name = 'GC_74',
                 value = 'ee**2*complex(0,1)*cmath.cos(theta)**2 + (cw**2*ee**2*complex(0,1)*cmath.cos(theta)**2)/(2.*sw**2) + (ee**2*complex(0,1)*sw**2*cmath.cos(theta)**2)/(2.*cw**2)',
                 order = {'QED':2})

GC_8 = Coupling(name = 'GC_8',
                value = '(ee**2*complex(0,1))/(2.*cw)',
                order = {'QED':2})

GC_9 = Coupling(name = 'GC_9',
                value = '-G',
                order = {'QCD':1})

